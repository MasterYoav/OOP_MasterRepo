public class SimpleDisc implements Disc
{
    private Player _owner;
    private Disc[][] _board;

    public SimpleDisc(Player owner)
    {
        this._owner = owner;
    }
    @Override
    public Player getOwner()
    {
        return _owner;
    }

    @Override
    public void setOwner(Player owner)
    {
        this._owner = owner;
    }

    @Override
    public String getType() {
        return "⬤";
    }
//    public Disc[][] get_board()
//    {
//        return _board;
//    }
}
