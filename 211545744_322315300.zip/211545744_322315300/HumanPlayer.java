public class HumanPlayer extends Player
{
    public HumanPlayer(boolean b) {
        super(b);
    }

    @Override
    boolean isHuman() {
        return true;
    }


}




