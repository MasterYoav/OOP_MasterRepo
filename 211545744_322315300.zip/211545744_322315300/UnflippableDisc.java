public class UnflippableDisc implements Disc
{
    private Player _owner;

    public UnflippableDisc(Player owner) {
        this._owner = owner;
    }

    @Override
    public Player getOwner()
    {

        return _owner;
    }

    @Override
    public void setOwner(Player owner)
    {
        this._owner = owner;
    }

    @Override
    public String getType()
    {
        return "⭕";
    }
}
