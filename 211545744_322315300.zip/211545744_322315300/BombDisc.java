import java.util.ArrayList;

public class BombDisc implements Disc
{
    private Player _owner;

    public BombDisc(Player owner)
    {
        this._owner = owner;
    }
    @Override
    public Player getOwner()
    {
        return _owner;
    }

    @Override
    public void setOwner(Player player)
    {
        this._owner = player;
    }

    @Override
    public String getType()
    {
        return "💣";
    }

}
